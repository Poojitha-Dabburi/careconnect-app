const express = require('express');
const sgMail = require('@sendgrid/mail');
const dotenv = require('dotenv');

// Load environment variables from .env file
dotenv.config();
console.log("SendGrid API Key: ", process.env.SENDGRID_API_KEY);

const app = express();
const port = 3000;

// Middleware to parse JSON body
app.use(express.json());

// POST route to send an email
app.post('/send-email', async (req, res) => {
    const { to, subject, message } = req.body;

    // Validate input data
    if (!to || !subject || !message) {
        return res.status(400).json({ error: 'Missing required fields: to, subject, or message.' });
    }

    sgMail.setApiKey(process.env.SENDGRID_API_KEY);

    const msg = {
        to: to,
        from: 'careconnect48@gmail.com',  // Replace with your SendGrid verified sender email
        subject: subject,
        text: message,
    };

    try {
        await sgMail.send(msg);
        res.status(200).json({ status: 'success', message: 'Email sent successfully' });
    } catch (error) {
        console.error('Error sending email:', error.response?.body || error.message || error);
        res.status(500).json({
            status: 'error',
            message: 'Failed to send email',
            error: error.response?.body || error.message || error,
        });
    }
    
});

// Start the server
app.listen(port, () => {
    console.log(`Server running on port ${port}`);
});
